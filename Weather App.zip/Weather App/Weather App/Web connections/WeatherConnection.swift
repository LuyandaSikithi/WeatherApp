//
//  WeatherConnection.swift
//  Weather App
//
//  Created by Luyanda Sikithi on 2019/11/14.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import Foundation

let API = "https://api.openweathermap.org/data/2.5/weather?lat=\(Location.sharedInstance.latitude!)&lon=\(Location.sharedInstance.longitude!)&appid=700857ba315b270b3650426bed154ee9"


// get latitude and longitude
let WEEK_API = "https://api.openweathermap.org/data/2.5/forecast?lat=-26.2041028&lon=28.0473051&appid=700857ba315b270b3650426bed154ee9"

typealias Downloaded = () -> ()

