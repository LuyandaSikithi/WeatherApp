//
//  ViewController.swift
//  Weather App
//
//  Created by Luyanda Sikithi on 2019/11/13.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import UIKit
import CoreLocation
import Alamofire
import SwiftyJSON
class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var temp: UILabel!
    @IBOutlet weak var weather_type: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var main_image: UIImageView!
    
    var locationManager: CLLocationManager!
    
    var myLocation: CLLocation!
    var weather: TodayWeather!
    var forecast: Forecast!
    var weeklyArray = [Forecast]()
    
    let headerView = UIView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        weather = TodayWeather()
        delegates()
        getForecastWeather{
            print("Done")
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        getLocation()
    }
    
    func connect() {
         if Connection.isConnectedToNetwork()
           {
               weather = TodayWeather()
           }
           else
           {
               DispatchQueue.main.async
               {
                let alertController = UIAlertController(title: "", message: "Your Phone is currenty not connected to the internent, Check your connection and try again.", preferredStyle: UIAlertController.Style.alert)
                alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                   self.present(alertController, animated: true, completion: nil)
               }
           }
    }
    
    func delegates(){
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func getLocation(){
        locationManager = CLLocationManager()
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        Location.sharedInstance.latitude = locValue.latitude
        Location.sharedInstance.longitude = locValue.longitude
        weather.downloadWeather {
            self.display()
        }
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        let status: CLAuthorizationStatus = CLLocationManager.authorizationStatus()
        if status == CLAuthorizationStatus.denied
        {
            getLocation()
        }
        
    }
 
    func display(){
        temp.text = weather.temp.toºcelsius()
        weather_type.text = weather.type!
       
        headerView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 50)
        tableView.tableHeaderView = headerView
        
        if weather.type == "Rain" {
            main_image.image = UIImage(named: "forest_rainy")
            tableView.backgroundColor = hexStringToUIColor(hex: "#57575D")
            headerView.backgroundColor = hexStringToUIColor(hex: "#57575D")
        }else if weather.type == "Clouds" {
            main_image.image = UIImage(named: "forest_cloudy")
            tableView.backgroundColor = hexStringToUIColor(hex: "#54717A")
            headerView.backgroundColor = hexStringToUIColor(hex: "#54717A")
        }else{
            main_image.image = UIImage(named: "forest_sunny")
            tableView.backgroundColor = hexStringToUIColor(hex: "#47AB2F")
            headerView.backgroundColor = hexStringToUIColor(hex: "#47AB2F")
        }
        
        
    }
    
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }

        if ((cString.count) != 6) {
            return UIColor.gray
        }

        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)

        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    func getForecastWeather(completed: @escaping Downloaded){
        
         AF.request(WEEK_API).responseJSON{(response) in
            let result = response.self
            
            if let dictionary = result.value as? Dictionary<String, AnyObject> {
                if let list = dictionary["list"] as? [Dictionary<String, AnyObject>] {
                    for item in list {
                        let forecast = Forecast(weather: item)
                        self.weeklyArray.append(forecast)
                    }
                    self.tableView.reloadData()
                }
            }
         }
     }
 }

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return weeklyArray.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "forecast", for: indexPath) as! ForecastTableViewCell
        
        cell.day.text = weeklyArray[indexPath.row].day
        cell.weatherTemp.text = weeklyArray[indexPath.row].temp.toºcelsius()
        
        if weeklyArray[indexPath.row].type == "Rain" {
            cell.weatherType.image = UIImage(named: "rain")
        }else if weeklyArray[indexPath.row].type == "Clouds" {
            cell.weatherType.image = UIImage(named: "partlysunny")
        }else{
            cell.weatherType.image = UIImage(named: "clear")
        }
        return cell
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = Bundle.main.loadNibNamed("HeaderTableViewCell", owner: self, options: nil)?.first as! HeaderTableViewCell
        
        header.min.text = "19"//"\(weather.min!)"
        header.current.text = "23"//"\(weather.temp!)"
        header.max.text = "25"//"\(weather.max!)"
        header.backView.backgroundColor = hexStringToUIColor(hex: "#54717A")
        return header
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 70
    }
}
