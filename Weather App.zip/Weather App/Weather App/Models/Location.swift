//
//  Location.swift
//  Weather App
//
//  Created by Luyanda Sikithi on 2019/11/14.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import Foundation

class Location {
    
    static var sharedInstance = Location()
    
    var latitude: Double!
    var longitude: Double!
}
