//
//  TodayWeather.swift
//  Weather App
//
//  Created by Luyanda Sikithi on 2019/11/14.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//
import Alamofire
import SwiftyJSON
import Foundation

class TodayWeather {
    
     var temp: Double!
     var type: String!
     var min: Double!
     var max: Double!
     
    var temprate: Double {
        if temp == nil {
            temp = 0.0
        }
        return temp
    }
    
    var wType: String {
        if type == nil {
            type = ""
        }
        return type
    }
    var minimum: Double {
        if min == nil {
            min = 0.0
        }
        return min
    }
  
    var maximum: Double {
        if max == nil {
            max = 0.0
        }
        return max
    }
    
    func downloadWeather(completed: @escaping Downloaded){
        AF.request(API).responseData{(response) in
            let result = JSON(response.data!)
            let temprature = result["main"]["temp"].double
            
            self.temp = (temprature! - 273.15).rounded(toPlaces: 0)
            
            self.type = result["weather"][0]["main"].stringValue
            
            let temp_min = result["main"]["temp_min"].double
            self.min = (temp_min! - 273.15).rounded(toPlaces: 0)
            
            let temp_max = result["main"]["temp_max"].double
            self.max = (temp_max! - 273.15).rounded(toPlaces: 0)
            completed()
        }
        
    }
}
