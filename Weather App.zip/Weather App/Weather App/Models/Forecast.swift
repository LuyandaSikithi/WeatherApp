//
//  Forecast.swift
//  Weather App
//
//  Created by Luyanda Sikithie on 2019/11/14.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import Foundation

class Forecast {
    
    
    /*var forecast: FocucastWeather!
    
    init(forecast: FocucastWeather) {
        self.forecast = forecast
    }*/
    
    var day: String!
    var temp: Double!
    var min: Double!
    var max: Double!
    var type: String!
    var times: String!
    
    var fType: String {
        if type == nil {
            type = ""
        }
        return type
    }
    
    var fDay: String {
        if day == nil {
            day = ""
        }
        return day
    }
    
    var fTemp: Double {
        if temp == nil {
            temp = 0.0
        }
        return temp
    }
    
    var fmin: Double {
        if min == nil {
            min = 0.0
        }
        return min
    }
    var fmax: Double {
        if max == nil {
            max = 0.0
        }
        return max
    }
    
    var fTime: String {
        if times == nil {
            times = ""
        }
        return times
    }
 
    init(weather: Dictionary<String, AnyObject>) {
        
        
        if let temp = weather["main"] as? Dictionary<String, AnyObject> {
            
            if let dayTemp = temp["temp"] as? Double {
                let rawValue = (dayTemp - 273.15).rounded(toPlaces: 0)
                self.temp = rawValue
                
            }
        }
        
        if let temp = weather["main"] as? Dictionary<String, AnyObject> {
            
            if let dayTemp = temp["temp_min"] as? Double {
                let rawValue = (dayTemp - 273.15).rounded(toPlaces: 0)
                self.min = rawValue
                
            }
        }
        
        if let temp = weather["main"] as? Dictionary<String, AnyObject> {
            
            if let dayTemp = temp["temp_max"] as? Double {
                let rawValue = (dayTemp - 273.15).rounded(toPlaces: 0)
                self.max = rawValue
                
            }
        }
        
        if let type = weather["weather"] as? [Dictionary<String, AnyObject>] {
            for items in type {
                if let dayType = items["main"] as? String {
                    
                    self.type = dayType
                }
            }
        }
        
        if let date = weather["dt"] as? Double {
            
            let rawDate = Date(timeIntervalSince1970: date)
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .medium
            self.day = "\(rawDate.dayOfTheWeek())"
        }
     
        if let dayTime = weather["dt_txt"] as? String {
            
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

            let yourDate = formatter.date(from: dayTime)
            formatter.dateFormat = "HH:mm"

            let myString = formatter.string(from: yourDate!)
            self.times = myString
            
        }
        
    }
    

    
    
}
