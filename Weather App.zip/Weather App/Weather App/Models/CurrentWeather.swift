//
//  CurrentWeather.swift
//  Weather App
//
//  Created by Luyanda Sikithi on 2019/11/19.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import Foundation
struct Currentweather{
    var temp: Double
    var type: String
    var min: Double
    var max: Double
}
