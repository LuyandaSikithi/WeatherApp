//
//  Extensions.swift
//  Weather App
//
//  Created by Luyanda Sikithi on 2019/11/14.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//
import UIKit
import Foundation

extension Double {
    func rounded(toPlaces places: Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return(self * divisor).rounded() / divisor
    }
    func toºcelsius() -> String {
        return String(format: "%.0f\("º")",self)
    }
}

extension Date {
    func dayOfTheWeek() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat? = "EEEE"
        return dateFormatter.string(from: self)
    }
    
    func toTime() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        let strDate = dateFormatter.string(from: (self))
        return strDate
    }
}
