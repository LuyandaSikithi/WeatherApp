//
//  HeaderTableViewCell.swift
//  Weather App
//
//  Created by Luyanda Sikithi on 2019/11/19.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import UIKit

class HeaderTableViewCell: UITableViewCell {

    @IBOutlet weak var min: UILabel!
    @IBOutlet weak var current: UILabel!
    @IBOutlet weak var max: UILabel!
    @IBOutlet weak var backView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
