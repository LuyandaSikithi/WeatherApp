//
//  ForecastTableViewCell.swift
//  Weather App
//
//  Created by Luyanda Sikithi on 2019/11/14.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import UIKit

class ForecastTableViewCell: UITableViewCell {

    
    @IBOutlet weak var day: UILabel!
    @IBOutlet weak var weatherType: UIImageView!
    @IBOutlet weak var weatherTemp: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
